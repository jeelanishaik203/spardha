<?php 
	session_start(); 

	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
		header('location: login.php');
	}

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location: login.php");
	}

?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700" rel="stylesheet">
      <meta charset="UTF-8">
      <meta content="width=device-width, initial-scale=1" name="viewport">
      <meta content="IE=edge" http-equiv="X-UA-Compatible">
      <title>Responsive Animated Image Grid | XO PIXEL</title>
      <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
      <link href="css/normalize.css" rel="stylesheet" type="text/css">
      <link href="css/demo.css" rel="stylesheet" type="text/css">
      <link href="css/xopixel.css" rel="stylesheet" type="text/css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
      <link rel="stylesheet" type="text/css" href="index2.css">
      <style>
        * {
  box-sizing: border-box;
}

/* Create two equal columns that floats next to each other */
.column1 {
  float: left;
  width: 70%;
  padding: 10px;
  height: 300px; /* Should be removed. Only for demonstration */
}
.column2 {
  float: left;
  width: 30%;
  padding: 10px;
  height: 300px; /* Should be removed. Only for demonstration */
}
/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column1 {
    width: 100%;
    height:auto;
  }
  .column2 {
    width: 100%;
    height:auto;
  }
}
      </style>
   </head>
   <body >
      <header >
         <nav class="navbar navbar-inverse">
            <div class="container-fluid">
               <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>                        
                  </button>
                  <a class="navbar-brand" href="#">For Sale</a>
               </div>
               <div class="collapse navbar-collapse" id="myNavbar">
                  <ul class="nav navbar-nav">
                     <li class="active">
                        <a href="index.html">Home</a>
                     </li>
                     <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Branch<span class="caret"></span></a>
                            <ul class="dropdown-menu">
                               <li><a href="displaycse.php">CSE</a></li>
                               <li><a href="#">IT</a></li>
                               <li><a href="#">MECH</a></li>
                               <li><a href="#">CIVIL</a></li>
                               <li><a href="#">ECE</a></li>
                               <li><a href="#">EEE</a></li>
                            </ul>
                         </li>
                         
                  </ul>
				<ul class="nav navbar-nav navbar-right">
                     <li><a href="register.php"><span class="glyphicon glyphicon-user"></span><?php echo $_SESSION['username']; ?></a></li>
                     <li><a href="index.php?logout='1'"><span class="glyphicon glyphicon-log-in"></span> Log Out</a></li>
                  </ul>
               </div>
            </div>
         </nav>

      </header>
           <div class="content">

		<!-- notification message -->
		<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h3>
					<?php 
						
						unset($_SESSION['success']);
					?>
				</h3>
			</div>
		<?php endif ?>

		<!-- logged in user information -->
		<?php  if (isset($_SESSION['username'])) : ?>
			
			<p> <a href="index.php?logout='1'" style="color: red;"></a> </p>
		<?php endif ?>
              <center>
            <h1 style="padding-top: 20%">Select Your Branch</h1>
         </center>
		 </div>
   </body>
</html>