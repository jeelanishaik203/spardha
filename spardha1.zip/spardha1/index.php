<?php 
	session_start(); 

	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
		header('location: login.php');
	}

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location: login.php");
	}

?>
<!DOCTYPE html>
<html>
<!DOCTYPE html>
<html lang="en">
   <head>
      <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700" rel="stylesheet">
      <meta charset="UTF-8">
      <meta content="width=device-width, initial-scale=1" name="viewport">
      <meta content="IE=edge" http-equiv="X-UA-Compatible">
      <title>Responsive Animated Image Grid | XO PIXEL</title>
      <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
      <link href="css/normalize.css" rel="stylesheet" type="text/css">
      <link href="css/demo.css" rel="stylesheet" type="text/css">
      <link href="css/xopixel.css" rel="stylesheet" type="text/css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
      <link rel="stylesheet" type="text/css" href="index2.css">
      <style>
        * {
  box-sizing: border-box;
}

/* Create two equal columns that floats next to each other */
.column1 {
  float: left;
  width: 70%;
  padding: 10px;
  height: 300px; /* Should be removed. Only for demonstration */
}
.column2 {
  float: left;
  width: 30%;
  padding: 10px;
  height: 300px; /* Should be removed. Only for demonstration */
}
/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column1 {
    width: 100%;
    height:auto;
  }
  .column2 {
    width: 100%;
    height:auto;
  }
}
      </style>
   </head>
<body>
      <header >
         <nav class="navbar navbar-inverse">
            <div class="container-fluid">
               <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>                        
                  </button>
                  <a class="navbar-brand" href="#">For Sale</a>
               </div>
               <div class="collapse navbar-collapse" id="myNavbar">
                  <ul class="nav navbar-nav">
                     <li class="active">
                        <a href="#">Home</a>
                     </li>
                     
                  </ul>
                  <ul class="nav navbar-nav navbar-right">
                     <li><a href="register.php"><span class="glyphicon glyphicon-user"></span><?php echo $_SESSION['username']; ?></a></li>
                     <li><a href="index.php?logout='1'"><span class="glyphicon glyphicon-log-in"></span> Log Out</a></li>
                  </ul>
               </div>
            </div>
         </nav>
         <center>
            <h1>Make A Deal</h1>
         </center>
      </header>
	<div class="content">

		<!-- notification message -->
		<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h3>
					<?php 
						
						unset($_SESSION['success']);
					?>
				</h3>
			</div>
		<?php endif ?>

		<!-- logged in user information -->
		<?php  if (isset($_SESSION['username'])) : ?>
			
			<p> <a href="index.php?logout='1'" style="color: red;"></a> </p>
		<?php endif ?>
		<div class="row">
                <div class="column1" >
                    <div class="xop-section">
                       <ul class="xop-grid">
                          <li>
                             <div class="xop-box xop-img-1">
                                <a href="xerox.php">
                                   <div class="xop-info">
                                      <h3>Xeroxes</h3>
                                      <p>Made Easier</p>
                                   </div>
                                </a>
                             </div>
                          </li>
                          <li>
                             <div class="xop-box xop-img-2">
                                <a href="#">
                                   <div class="xop-info">
                                      <h3>Notes</h3>
                                      <p>Taking notes help you make sense of the text.</p>
                                   </div>
                                </a>
                             </div>
                          </li>
                          <li>
                             <div class="xop-box xop-img-3">
                                <a href="#">
                                   <div class="xop-info">
                                      <h3>Text Books</h3>
                                      <p>Effective textbook reading is a key study skill for student success.</p>
                                   </div>
                                </a>
                             </div>
                          </li>
                          <li>
                             <div class="xop-box xop-img-4">
                                <a href="#">
                                   <div class="xop-info">
                                      <h3>Projects</h3>
                                      <p>Nothing ever gets done at group meetings because you spend the entire time talking about how stupid the project is. </p>
                                   </div>
                                </a>
                             </div>
                          </li>
                          <li>
                             <div class="xop-box xop-img-1">
                                <a href="#">
                                   <div class="xop-info">
                                      <h3>Stationary</h3>
                                      <p> It was a matter of pride to bring these things to class and while we grew up and entered college, the love affair with stationery continued.</p>
                                   </div>
                                </a>
                             </div>
                          </li>
                          <li>
                             <div class="xop-box xop-img-1">
                                <a href="#">
                                   <div class="xop-info">
                                      <h3>Question Papers</h3>
                                      <p>Yes, all previous year papers more helpfull for you. In that atleast you have idea about the papers pattern, difficult level of section topic-wise and subject wise, ...</p>
                                   </div>
                                </a>
                             </div>
                          </li>
                          <li>
                             <div class="xop-box xop-img-4">
                                <a href="#">
                                   <div class="xop-info">
                                      <h3>PPTs</h3>
                                      <p>It's not about how you do, It's about how you present..</p>
                                   </div>
                                </a>
                             </div>
                          </li>
                          <li>
                             <div class="xop-box xop-img-1">
                                <a href="#">
                                   <div class="xop-info">
                                      <h3>Paint</h3>
                                      <p>Nulla commodo iaculis vulputate. Nullam enim mauris, dignissim id est nec, mollis pretium nulla.</p>
                                   </div>
                                </a>
                             </div>
                          </li>
                          <li>
                             <div class="xop-box xop-img-1">
                                <a href="#">
                                   <div class="xop-info">
                                      <h3>Paint</h3>
                                      <p>Nulla commodo iaculis vulputate. Nullam enim mauris, dignissim id est nec, mollis pretium nulla.</p>
                                   </div>
                                </a>
                             </div>
                          </li>
                       </ul>
                    </div>
                </div>
        
        <style>
            .mobile-form-holder {
            width: 500px;
            margin: 0 auto;
            }
            .form-row {
            width: 100%;
            position: relative;
            }
            .form-label {
            height: 50px;
            }
            .form-field {
            width: 100%;
            height: 50px;
            }
            .form-field input {
            width: 100%;
            height: 50px;
            padding: 0 0 0 5px;
            border: 1px solid #ccc;
            }
            .form-field input {
            background:rgb(112, 105, 105);
            }
            .form-field input:focus {
            background: black;
            } ::placeholder {
            color:white;
            opacity: 1; 
            }
            input[type="text"] {
            color: white;
            }
            @media (max-width: 600px) {
            .form-label {
            padding: 15px 0 0 5px;
            }
            .form-field {
            position: absolute;
            top: 0;
            }
            .form-field input {
            background:rgb(112, 105, 105);
            }
            .form-field input:focus {
            background: black;
            }  
            ::placeholder {
            color:white;
            opacity: 1; 
            }
            input[type="text"] {
            color: white;
            }
            }
         </style>
        <div class="column2" >
            
            <div class="mobile-form-holder" style="padding-top:100px;padding-right:200px;">
               <div class="form-row">
                  <div class="form-field"style="padding-bottom:200px">
                     <input type="text" placeholder="Post your Need Here">
                     <center>
                        <div style="padding-top:30px"><a href="#" class ="btn btn-danger btn-lg active" >POST</a></div>
                     </center>
                  </div>
               </div>
            </div>
            
         </div>
        </div>
	</div>
		
</body>
</html>