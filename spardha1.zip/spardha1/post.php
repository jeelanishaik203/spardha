<?php 

$name= $_FILES['file']['name'];

$tmp_name= $_FILES['file']['tmp_name'];

$submitbutton= $_POST['submit'];

$position= strpos($name, "."); 

$fileextension= substr($name, $position + 1);

$fileextension= strtolower($fileextension);


$uname= $_POST['name'];
$pname= $_POST['ppname'];
$price= $_POST['price'];
$mobile= $_POST['mobile'];



if (isset($name)) {



if (!empty($name)){
if (move_uploaded_file($tmp_name, "stationaryfiles/".$name)) {
echo 'Uploaded!';}
else{
echo"not uploaded";}

}
}

$user = "root"; 
$password = ""; 
$host = "localhost"; 
$dbase = "spardha"; 
$table = "stationary"; 


$connection= mysql_connect ($host, $user, $password);
if (!$connection)
{
die ('Could not connect:' . mysql_error());
}
mysql_select_db($dbase, $connection);


if(!empty($pname)&&!empty($uname)&&!empty($price)&&!empty($mobile)){
mysql_query("INSERT INTO $table (productname, username,price,mobileno,filename)
VALUES ('$pname', '$uname', '$price', '$mobile', '$name')");
}

mysql_close($connection);



$user = "root"; 
$password = ""; 
$host = "localhost"; 
$dbase = "spardha"; 
$table = "stationary"; 
// Connection to DBase 
mysql_connect($host,$user,$password); 
@mysql_select_db($dbase) or die("Unable to select database");

$result= mysql_query( "SELECT productname, username,price,mobileno,filename FROM $table" ) 
or die("SELECT Error: ".mysql_error()); 
print "<table border=0>\n"; 
print "<tr>\n";
$count=0;
while ($row = mysql_fetch_array($result)){ 
if($count<4){
$files_field= $row['filename'];
$files_show= "stationaryfiles/$files_field";
$pname1= $row['productname'];
$uname1= $row['username'];
$price1= $row['price'];
$mobileno1= $row['mobileno'];
print "\t<td>\n"; 
echo "<div>";
echo "<div ><img src='$files_show' height='100px' width='auto'>$files_field</div><br>";
echo "<font face=arial size=4 align=center>$pname1<br>$uname1<br>$price1<br>$mobileno1</font>";
echo"</div>";
print "</td>\n";
$count=$count+1;
}
else{
	$count=0;
	print "<tr>\n";
}
} 
print "</tr>\n"; 
print "</table>\n"; 


?>

